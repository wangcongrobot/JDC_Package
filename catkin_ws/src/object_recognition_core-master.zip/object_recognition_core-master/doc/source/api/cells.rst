Cells API
=========

.. ectomodule:: object_recognition_core.ecto_cells.db

.. ectomodule:: object_recognition_core.ecto_cells.io

.. ectomodule:: object_recognition_ros.ecto_cells.io_ros

.. ectomodule:: object_recognition_core.ecto_cells.filters

.. ectomodule:: object_recognition_core.ecto_cells.voter
