#!/bin/sh -e
. $1
$2 $3
