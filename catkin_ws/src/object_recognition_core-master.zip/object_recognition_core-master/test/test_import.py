#!/usr/bin/env python
from object_recognition_core import *
from object_recognition_core.io.sink import *
from object_recognition_core.io.source import *
from object_recognition_core.io.voter import *
