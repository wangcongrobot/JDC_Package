Object Recognition
==================

Please see http://ecto.willowgarage.com/recognition.

