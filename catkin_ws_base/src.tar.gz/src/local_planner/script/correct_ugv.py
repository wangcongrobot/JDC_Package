
# coding: utf-8

# In[3]:


import rospy
from id_data_msgs.msg import ID_Data
from sensor_msgs.msg import LaserScan

class correct_pose():
    def __init__(self):
        rospy.init_node('sim_control', anonymous=True)
        self.leftd = 0.0
        self.rightd = 0.0
        self.Is_scanInitialed = False
        self.Is_noticeInitialed = False
        self.state = ID_Data()
        rospy.Subscriber("/scan", LaserScan, self.scanCallback, queue_size=1)
        rospy.Subscriber("/notice", ID_Data, self.noticeCallback, queue_size=1)
        self.pub = rospy.Publisher("/notice", ID_Data, queue_size=1)
        rate = rospy.Rate(10) # 10hz
        while not rospy.is_shutdown():
            if self.Is_scanInitialed and self.Is_noticeInitialed:
                if self.state.id == 2 and self.state.data[0] == 15:
                    cmd_notice = ID_Data()
                    cmd_notice.id = 2
                    cmd_notice.data[0] = 4
                    cmd_notice.data[1] = int(self.leftd*100-63)
		    print self.leftd
                    self.pub.publish(cmd_notice)
            rate.sleep()        
        
    def scanCallback(self, data):
        if self.Is_scanInitialed == False:
            self.Is_scanInitialed = True            
        self.leftd = data.ranges[-1]
        self.rightd = data.ranges[0]
        
    def noticeCallback(self, data):
        if self.Is_noticeInitialed == False:
            self.Is_noticeInitialed = True 
        self.state = data
    


if __name__ == '__main__':
    cp = correct_pose()

